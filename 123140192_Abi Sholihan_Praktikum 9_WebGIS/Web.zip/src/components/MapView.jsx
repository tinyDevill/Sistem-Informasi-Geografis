import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import { useEffect, useState } from 'react'
import api from '../services/api'

export default function MapView() {
  const [data, setData] = useState([])

  const fetchData = async () => {
    const res = await api.get('/api/fasilitas')
    setData(res.data)
  }

  useEffect(() => {
    fetchData()
  }, [])

  // DELETE
  async function deleteData(id) {
    await api.delete(`/api/fasilitas/${id}`)
    fetchData()
  }

  // UPDATE
  async function updateData(id) {
    await api.put(`/api/fasilitas/${id}`, {
      nama: "Updated dari React"
    })
    fetchData()
  }

  // CREATE
  async function addData() {
    await api.post('/api/fasilitas', {
      nama: "Fasilitas Baru",
      jenis: "Umum",
      alamat: "Lampung",
      longitude: 105.25,
      latitude: -5.40
    })
    fetchData()
  }

  return (
    <div>
      {/* tombol tambah global */}
      <button onClick={addData} style={{position: 'absolute', zIndex: 1000}}>
        Tambah Fasilitas
      </button>

      <MapContainer center={[-5.4, 105.25]} zoom={13} style={{height: "100vh"}}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

        {data.map((item) => (
          <Marker key={item.id} position={[item.lat, item.lon]}>
            <Popup>
              <b>{item.nama}</b><br/>
              {item.jenis}<br/>

              <button onClick={() => updateData(item.id)}>Edit</button>
              <br/>
              <button onClick={() => deleteData(item.id)}>Delete</button>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}